'use client';

import Ecomuser from '@/models/user';
import bcrypt from 'bcryptjs';

export type AuthUser = {
  _id: string;
  name: string;
  email: string;
  phone: string;
  dob: string;
  age: number;
  status: 'Active' | 'InActive';
  token?: string;
};

// Save user to localStorage (and optionally cookies)
export function setAuth(user: AuthUser) {
  localStorage.setItem('user', JSON.stringify(user));
  document.cookie = `token=${user.token}; path=/`;
}

// Get user from localStorage
export function getAuth(): AuthUser | null {
  if (typeof window === 'undefined') return null;
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
}

// Remove user on logout
export function clearAuth() {
  localStorage.removeItem('user');
  document.cookie = 'token=; Max-Age=0; path=/';
}

// Check if user is logged in
export function isLoggedIn(): boolean {
  return !!getAuth();
}

//validate user with combination of email and password
export async function validateUser(email: string, password: string) {
  console.log(
    'comming for check email esists or not with validateUser() with email',
    email + ' - ' + password,
  );
  const user = await Ecomuser.findOne({ email });
  console.log('get user object from mongodb by email', user);
  if (!user) return null;

  const isMatch = await bcrypt.compare(password, user.password);
  return isMatch ? user : null;
}
