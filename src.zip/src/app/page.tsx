export default function Home() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Welcome to MyShop!</h1>
      <p>This is the home page.</p>
    </div>
  );
}
