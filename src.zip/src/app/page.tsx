export default function Home() {
  return (
    <div className="text-center py-16">
      <h1 className="text-4xl font-bold mb-4">Welcome to MyShop!</h1>
      <p className="text-lg text-gray-600">This is the home page.</p>
    </div>
  );
}
