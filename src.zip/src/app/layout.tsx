import './globals.css';
import { Geist, Geist_Mono } from 'next/font/google';
import ThemeRegistry from '../ThemeRegistry';
import { store } from '@/lib/store';
import { Provider } from 'react-redux';

const geistSans = Geist({ variable: '--font-geist-sans', subsets: ['latin'] });
const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata = {
  title: 'Next.js CRUD App',
  description: 'Professional setup',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${geistSans.variable} ${geistMono.variable}`}>
        <Provider store={store}>
          <ThemeRegistry>{children}</ThemeRegistry>
        </Provider>
      </body>
    </html>
  );
}
