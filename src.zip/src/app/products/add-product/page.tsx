'use-client';

import AuthLayout from '@/components/AuthLayout';

export default function AddProductPage() {
  return (
    <AuthLayout>
      <div>
        <h1 className="text-xl font-bold mb-4">Add Product Screen</h1>
      </div>
    </AuthLayout>
  );
}
