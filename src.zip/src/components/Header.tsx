'use client';

import Link from 'next/link';
import { useAppSelector, useAppDispatch } from '@/redux/hooks';
import { logout, login } from '@/redux/slices/userSlice';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { getAuth, clearAuth } from '@/lib/auth';

export default function Header() {
  const { user } = useAppSelector((state) => state.user);
  const dispatch = useAppDispatch();
  const router = useRouter();

  useEffect(() => {
    const authUser = getAuth();
    if (authUser) {
      dispatch(login(authUser));
    }
  }, [dispatch]);

  const handleLogout = () => {
    dispatch(logout());
    clearAuth();
    router.push('/');
  };

  return (
    <header className="bg-gray-800 text-white p-4 flex justify-between items-center">
      <div className="flex items-center gap-4">
        <span className="text-xl font-bold">🛒 MyShop</span>
        <nav className="flex gap-4">
          <Link href="/">Home</Link>
          <Link href="/products">All Products</Link>
          {user && <Link href="/products/add-product">Add Product</Link>}
        </nav>
      </div>
      <div className="flex items-center gap-3">
        {!user ? (
          <Link href="/account/login">Login</Link>
        ) : (
          <>
            <Link href="/account/me">My Account</Link>
            <button onClick={handleLogout}>Logout</button>
          </>
        )}
      </div>
    </header>
  );
}
