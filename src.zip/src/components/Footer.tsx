'use client';

// components/Footer.tsx
export default function Footer() {
  return (
    <footer className="bg-gray-200 text-center p-4 text-sm text-gray-600">
      &copy; {new Date().getFullYear()} MyShop. All rights reserved.
    </footer>
  );
}
