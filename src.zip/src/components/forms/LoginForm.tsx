'use client';

import { loginSchema } from '@/validations/loginSchema';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import {
  Box,
  TextField,
  Button,
  Typography,
  IconButton,
  InputAdornment,
  Link as MuiLink,
  Stack,
  Paper,
} from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';

import axiosClient from '@/helper/axios.client';
import { useRouter } from 'next/navigation';
import { setAuth } from '@/lib/auth';
import { useState } from 'react';

import { CustomizedDialogs } from '@/helper/customized.dialogs';

export default function LoginForm() {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(loginSchema),
  });

  const onSubmit = async (data) => {
    try {
      const baseURL = await axiosClient.defaults.baseURL;
      console.log('axios client baseURL::', baseURL);

      /*const res = await axiosClient.post('/api/auth/login', data);
      const { token, user } = res.data;
      localStorage.setItem('ACCESS_TOKEN', token);
      setAuth({ ...user, token });
      CustomizedDialogs('Success !!', 'User logedin successfully!');*/
      router.push('/account/me');
    } catch (error) {
      console.log(error);
      //alert('Invalid credentials');
      CustomizedDialogs('Error !!', 'Please enter valid credentials.');
    }
  };

  return (
    <Box
      display="flex"
      justifyContent="center"
      alignItems="center"
      minHeight="30vh"
      bgcolor="#f9f9f9"
    >
      <Paper elevation={3} sx={{ p: 5, width: 400, borderRadius: 3 }}>
        <Typography
          variant="h5"
          fontWeight="bold"
          textAlign="center"
          mb={3}
          style={{ height: '50px' }}
        >
          &nbsp;
        </Typography>

        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          <Stack spacing={5}>
            {/* Email Field with spacing */}
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center',
                width: '80%',
                gap: 5,
              }}
              style={{ height: '70px' }}
            >
              <TextField
                label="Email"
                sx={{ width: '80%' }}
                {...register('email')}
                inputProps={{ style: { height: '40px', padding: '10px' } }}
                error={!!errors.email}
                style={{ height: '70px' }}
                helperText={errors.email?.message}
              />
            </Box>
            <Box display="flex" justifyContent="flex-end" px={5}>
              &nbsp;
            </Box>
            {/* Password Field with spacing */}
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center',
                width: '80%',
                gap: 5,
              }}
              style={{ height: '50px' }}
            >
              <TextField
                label="Password"
                type={showPassword ? 'text' : 'password'}
                sx={{ width: '80%' }}
                {...register('password')}
                error={!!errors.password}
                helperText={errors.password?.message}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowPassword((prev) => !prev)} edge="end">
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                  style: {
                    height: '40px',
                    padding: '10px',
                  },
                }}
              />
            </Box>

            {/* Forgot Password */}
            <Box display="flex" justifyContent="flex-end" px={2}>
              <MuiLink
                href="#"
                fontSize="0.875rem"
                underline="hover"
                style={{ marginRight: '20px' }}
              >
                Forgot?
              </MuiLink>
            </Box>

            {/* Buttons with better spacing */}
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center',
                width: '100%',
                gap: 5,
                px: 4,
              }}
              style={{ height: '70px', display: 'flex', flexDirection: 'column' }}
            >
              <Stack
                direction="row"
                spacing={4}
                sx={{ width: '75%', justifyContent: 'center', alignItems: 'center' }}
              >
                <Button
                  type="button"
                  variant="outlined"
                  fullWidth
                  sx={{ py: 3, width: '75%' }}
                  onClick={() => reset()}
                  style={{ margin: '10px' }}
                >
                  Reset
                </Button>
                <Button
                  type="submit"
                  variant="contained"
                  fullWidth
                  sx={{ py: 3, width: '75%' }}
                  style={{ margin: '10px' }}
                >
                  Login Now
                </Button>
              </Stack>
            </Box>

            {/* Signup Link */}
            <Typography fontSize="0.9rem" textAlign="center" mt={2} style={{ height: '50px' }}>
              Don&apos;t have an account?{' '}
              <MuiLink href="/account/register" underline="hover">
                Sign up
              </MuiLink>
            </Typography>
          </Stack>
        </form>
      </Paper>
    </Box>
  );
}
